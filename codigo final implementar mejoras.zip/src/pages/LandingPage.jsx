
import React from 'react';
export default function LandingPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-3xl">Redirecting to Lobby...</h1>
    </div>
  );
}
